public class EmailSender {

    public void sendReportByEmail(String email, String filename) {
        System.out.println("Sending report " + filename + " to " + email);
        // kod wysyłający e-mail...
    }
}

