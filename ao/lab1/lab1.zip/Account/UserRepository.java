public class UserRepository {

    public void saveToDatabase(String username, String email, String password) {
        System.out.println("Saving user to database: " + username);
    }
}

