public class EmailService {

    public void sendActivationEmail(String email) {
        System.out.println("Sending activation email to: " + email);
    }
}

